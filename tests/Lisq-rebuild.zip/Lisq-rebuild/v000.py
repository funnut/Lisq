# v000 Ogólna struktura programu

def _test(args):
    print(args)

# dispatch table
commands = {
        "echo": lambda args: _test(" ".join(args)),
}

def main():
    while True:
        try:
            raw = input("> ").strip()
            if not raw:
                continue
            if raw in ["quit","q"]:
                return

            parts = raw.split()
            cmd = parts[0].lower()
            args = parts[1:]

            if cmd in commands:
                commands[cmd](args)
            else:
                raise ValueError(f"Nieprawidłowe polecenie: {cmd} {' '.join(args) if args else ''}")

        except ValueError as e:
            print ("Nieprawidłowe polecenie.")
        except KeyboardInterrupt as e:
            print ("KeyboardInterrupt Error")
            return
        except EOFError as e:
            print ("Zamknięto")
            return
        except Exception as e:
            print (f"Błąd: {e}")


if __name__ == "__main__":
    main()
